<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Technical\\app\\Providers\\TechnicalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Technical\\app\\Providers\\TechnicalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);